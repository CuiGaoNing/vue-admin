<template>
  <div class="home-index">
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
    bbbbbbbbbbbbbbb<br>
  </div>
</template>
<script>
import globalMixins from '@/mixins/globalMixins.js'
import service from './index-service.js'
export default {
  name: 'home-index1',
  mixins: [service, globalMixins],
  data () {
    return {
    }
  },
  methods: {
  },
  mounted () {
  },
  created () {
  }
}
</script>
<style lang="scss" scoped>
  @import '@/styles/common.scss';
  .span_number{
    position: absolute;
    font-size: 16px;
    width: 200px;
  }
  .databaseViewTitel{
    text-align: right;
    padding-right: 15px;
    position: absolute;
    top: 3px;
    right: 4px;
  }
</style>
