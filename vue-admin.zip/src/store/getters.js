const getters = {
  token: state => state.base.token,
  version: state => state.base.version,
  menuList: state => state.base.menuList
}
export default getters
