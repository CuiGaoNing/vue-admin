export default [{
  path: null,
  label: '',
  type: 'group',
  children: [{
    path: 'install',
    label: '首页',
    type: 'doc',
    author: ''
  }, {
    path: 'quick_start',
    label: '个人中心',
    type: 'doc',
    author: ''
  }, {
    path: 'custom_theme',
    label: '我的订单',
    type: 'doc',
    author: ''
  }]
}]
